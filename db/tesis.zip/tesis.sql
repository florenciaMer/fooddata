-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 09-10-2021 a las 13:28:28
-- Versión del servidor: 10.4.16-MariaDB
-- Versión de PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tesis`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `categoria_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`categoria_id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Panaderia', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(2, 'Almacen', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(3, 'Carnes', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(4, 'Pescados', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(5, 'Verduras', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(6, 'Frutas', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(7, 'Aves', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(8, 'Pescados', '2021-10-09 14:27:29', '2021-10-09 14:27:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `cliente_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombreFantasia` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `condicion_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`cliente_id`, `nombre`, `nombreFantasia`, `direccion`, `created_at`, `updated_at`, `condicion_id`, `usuario_id`) VALUES
(1, 'Arcor SA', 'Arcor', 'Av. Congreso 2655 CABA', '2021-10-09 14:27:29', '2021-10-09 14:27:29', 1, 1),
(2, 'Toyota Argentina SA', 'Toyota Zarate', 'Av. Santa Fe 3955 CABA', '2021-10-09 14:27:29', '2021-10-09 14:27:29', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clienteservicios`
--

CREATE TABLE `clienteservicios` (
  `clienteServicio_id` smallint(5) UNSIGNED NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `precio` decimal(8,2) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `etiqueta_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clienteservicios`
--

INSERT INTO `clienteservicios` (`clienteServicio_id`, `cliente_id`, `precio`, `created_at`, `updated_at`, `usuario_id`, `etiqueta_id`) VALUES
(1, 1, '150.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 1),
(2, 1, '450.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 2),
(3, 2, '450.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 2),
(4, 2, '150.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `condiciones`
--

CREATE TABLE `condiciones` (
  `condicion_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `condiciones`
--

INSERT INTO `condiciones` (`condicion_id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Exento', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(2, 'Gravado', '2021-10-09 14:27:29', '2021-10-09 14:27:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `etiquetas`
--

CREATE TABLE `etiquetas` (
  `etiqueta_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `etiquetas`
--

INSERT INTO `etiquetas` (`etiqueta_id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Desayuno', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(2, 'Almuerzo', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(3, 'Merienda', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(4, 'Cena', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(5, 'Refrigerio', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(6, 'Colacion', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(7, 'Vianda', '2021-10-09 14:27:29', '2021-10-09 14:27:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingredientes`
--

CREATE TABLE `ingredientes` (
  `ingrediente_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `precio` bigint(20) UNSIGNED NOT NULL,
  `impuesto` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unidad_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `categoria_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ingredientes`
--

INSERT INTO `ingredientes` (`ingrediente_id`, `nombre`, `precio`, `impuesto`, `created_at`, `updated_at`, `unidad_id`, `categoria_id`, `usuario_id`) VALUES
(1, 'Panal de Membrillo', 2500, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 1, 1),
(2, 'Pan Flauta', 3000, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 1, 1),
(3, 'Pan Saborizado', 23000, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 1, 1),
(4, 'Huevo', 1500, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 2, 2),
(5, 'Leche en polvo', 6000, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 2, 2),
(6, 'Azucar a granel', 9000, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 2, 2),
(7, 'Harina', 9000, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 1, 2, 2),
(8, 'Aceite', 10500, 21, '2021-10-09 03:00:00', '2021-10-09 03:00:00', 3, 2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_08_30_141213_create_usuarios_tables', 1),
(6, '2021_08_31_144837_create_ingredientes_tables', 1),
(7, '2021_08_31_150606_create_unidades_table', 1),
(8, '2021_08_31_150617_create_categorias_table', 1),
(9, '2021_08_31_151526_add_unidades_id_column_to_ingredientes_table', 1),
(10, '2021_08_31_151540_add_categorias_id_column_to_ingredientes_table', 1),
(11, '2021_08_31_152152_add_usuarios_id_column_to_ingredientes_table', 1),
(12, '2021_09_05_143449_create_recetas_table', 1),
(13, '2021_09_05_184226_create_recetas_items_tables', 1),
(14, '2021_09_05_184614_add_ingredientes_id_column_to_recetas_items_table', 1),
(15, '2021_09_05_223454_add_usuario_id_column_to_recetas_table', 1),
(16, '2021_09_05_224342_add_usuario_id_column_to_recetas_items_table', 1),
(17, '2021_09_06_185922_create_tipos_tables', 1),
(18, '2021_09_06_190842_add_tipo_id_column_to_recetas_table', 1),
(19, '2021_09_16_185925_create_etiquetas_tables', 1),
(20, '2021_09_16_201216_create_clientes_tables', 1),
(21, '2021_09_16_203342_create_condiciones_tables', 1),
(22, '2021_09_17_003427_add_condicion_id_column_to_clientes_table', 1),
(23, '2021_09_17_171132_add_usuario_id_column_to_clientes_table', 1),
(24, '2021_09_18_123615_create_clienteservicios_table', 1),
(25, '2021_09_18_124317_add_usuarios_id_column_to_clientesservicios_table', 1),
(26, '2021_09_18_124550_add_etiqueta_id_column_to_clientesservicios_table', 1),
(27, '2021_09_20_170056_create_table_planificacion', 1),
(28, '2021_09_20_170911_add_usuario_id_column_to_planificacion_table', 1),
(29, '2021_09_20_171508_add_cliente_column_to_planificacion_table', 1),
(30, '2021_09_26_132521_create_table_planificacion_item', 1),
(31, '2021_09_26_132752_add_usuario_column_to_planificacion_item', 1),
(32, '2021_09_26_132838_add_tipo_column_to_planificacion_item', 1),
(33, '2021_09_26_132920_add_receta_column_to_planificacion_item', 1),
(34, '2021_09_26_132955_add_etiqueta_column_to_planificacion_item', 1),
(35, '2021_09_26_140116_add_planificacion_column_to_planificacion_item', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion`
--

CREATE TABLE `planificacion` (
  `planificacion_id` smallint(5) UNSIGNED NOT NULL,
  `observaciones` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `cant` int(11) NOT NULL,
  `contexto` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `cliente_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `planificacion`
--

INSERT INTO `planificacion` (`planificacion_id`, `observaciones`, `cant`, `contexto`, `fecha`, `created_at`, `updated_at`, `usuario_id`, `cliente_id`) VALUES
(1, 'Corresponde a un servicio habitual', 100, 'Escenario', '2021-09-28', '2021-10-09 14:27:30', '2021-10-09 14:27:30', 1, 1),
(2, 'Corresponde a un servicio habitual', 50, 'Escenario', '2021-09-30', '2021-10-09 14:27:30', '2021-10-09 14:27:30', 1, 1),
(3, 'Corresponde a un servicio habitual', 25, 'Servicio habitual', '2021-10-09', '2021-10-09 14:27:30', '2021-10-09 14:27:30', 1, 2),
(4, 'Corresponde a un servicio habitual', 20, 'Servicio habitual', '2021-10-09', '2021-10-09 14:27:30', '2021-10-09 14:27:30', 2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion_item`
--

CREATE TABLE `planificacion_item` (
  `planificacionItem_id` smallint(5) UNSIGNED NOT NULL,
  `cant_rec` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `tipo_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `receta_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `etiqueta_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `planificacion_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `planificacion_item`
--

INSERT INTO `planificacion_item` (`planificacionItem_id`, `cant_rec`, `created_at`, `updated_at`, `usuario_id`, `tipo_id`, `receta_id`, `etiqueta_id`, `planificacion_id`) VALUES
(1, 100, '2021-10-09 14:27:30', '2021-10-09 14:27:30', 1, 1, 1, 1, 1),
(2, 50, '2021-10-09 14:27:30', '2021-10-09 14:27:30', 1, 1, 2, 1, 2),
(3, 25, '2021-10-09 14:27:30', '2021-10-09 14:27:30', 2, 1, 3, 1, 2),
(4, 20, '2021-10-09 14:27:30', '2021-10-09 14:27:30', 2, 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetas`
--

CREATE TABLE `recetas` (
  `receta_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `base` int(11) NOT NULL,
  `imagen` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `tipo_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recetas`
--

INSERT INTO `recetas` (`receta_id`, `nombre`, `descripcion`, `base`, `imagen`, `created_at`, `updated_at`, `usuario_id`, `tipo_id`) VALUES
(1, 'Huevo Duro', 'Receta: 1- Poner huevo y batir a punto nieve', 100, 'prox.jpg', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 1),
(2, 'Bizcochuelo base', 'Paso 1- Batir los huevos', 100, 'prox.jpg', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 2, 4),
(3, 'Huevos Revueltos', 'Paso 1- Los huevo se deben batir ', 100, 'prox.jpg', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetasitems`
--

CREATE TABLE `recetasitems` (
  `recetaItem_id` smallint(5) UNSIGNED NOT NULL,
  `receta_id` int(11) NOT NULL,
  `cant` decimal(8,2) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ingrediente_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `usuario_id` smallint(5) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recetasitems`
--

INSERT INTO `recetasitems` (`recetaItem_id`, `receta_id`, `cant`, `created_at`, `updated_at`, `ingrediente_id`, `usuario_id`) VALUES
(1, 1, '100.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 4, 2),
(2, 1, '6.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 8, 3),
(3, 2, '6.00', '2021-10-09 03:00:00', '2021-10-09 03:00:00', 8, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `tipo_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`tipo_id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Entrada', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(2, 'Plato Principal', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(3, 'Guarnición', '2021-10-09 14:27:29', '2021-10-09 14:27:29'),
(4, 'Postre', '2021-10-09 14:27:29', '2021-10-09 14:27:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

CREATE TABLE `unidades` (
  `unidad_id` smallint(5) UNSIGNED NOT NULL,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `unidades`
--

INSERT INTO `unidades` (`unidad_id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Kilogramos', '2021-10-09 14:27:28', '2021-10-09 14:27:28'),
(2, 'Unidad', '2021-10-09 14:27:28', '2021-10-09 14:27:28'),
(3, 'Litros', '2021-10-09 14:27:28', '2021-10-09 14:27:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usuario_id` smallint(5) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` int(11) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usuario_id`, `email`, `nombre`, `rol`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Admin@gmail.com', 'admin', 1, '$2y$10$Wsx6vVCpLsQQeunGVHdim.RJEyteMs5/33c4Vimr60Mc7LrWshxBG', '2021-10-09 03:00:00', '2021-10-09 03:00:00'),
(2, 'maria@gmail.com', 'Maria', 2, '$2y$10$Gq7iVSmBIPfWlOllaYj3JOSv3J.0jKfGedxZ40WArMIbuy4RFwxrS', '2021-10-09 03:00:00', '2021-10-09 03:00:00'),
(3, 'jose@gmail.com', 'Jose', 2, '$2y$10$WHfX0pAftorcYSo4lwtTme0uSB4XBnZBx/frQWuft8.wNL0TV034u', '2021-10-09 03:00:00', '2021-10-09 03:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`categoria_id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`cliente_id`),
  ADD KEY `clientes_condicion_id_foreign` (`condicion_id`),
  ADD KEY `clientes_usuario_id_foreign` (`usuario_id`);

--
-- Indices de la tabla `clienteservicios`
--
ALTER TABLE `clienteservicios`
  ADD PRIMARY KEY (`clienteServicio_id`),
  ADD KEY `clienteservicios_usuario_id_foreign` (`usuario_id`),
  ADD KEY `clienteservicios_etiqueta_id_foreign` (`etiqueta_id`);

--
-- Indices de la tabla `condiciones`
--
ALTER TABLE `condiciones`
  ADD PRIMARY KEY (`condicion_id`);

--
-- Indices de la tabla `etiquetas`
--
ALTER TABLE `etiquetas`
  ADD PRIMARY KEY (`etiqueta_id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `ingredientes`
--
ALTER TABLE `ingredientes`
  ADD PRIMARY KEY (`ingrediente_id`),
  ADD KEY `ingredientes_unidad_id_foreign` (`unidad_id`),
  ADD KEY `ingredientes_categoria_id_foreign` (`categoria_id`),
  ADD KEY `ingredientes_usuario_id_foreign` (`usuario_id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `planificacion`
--
ALTER TABLE `planificacion`
  ADD PRIMARY KEY (`planificacion_id`),
  ADD KEY `planificacion_usuario_id_foreign` (`usuario_id`),
  ADD KEY `planificacion_cliente_id_foreign` (`cliente_id`);

--
-- Indices de la tabla `planificacion_item`
--
ALTER TABLE `planificacion_item`
  ADD PRIMARY KEY (`planificacionItem_id`),
  ADD KEY `planificacion_item_usuario_id_foreign` (`usuario_id`),
  ADD KEY `planificacion_item_tipo_id_foreign` (`tipo_id`),
  ADD KEY `planificacion_item_receta_id_foreign` (`receta_id`),
  ADD KEY `planificacion_item_etiqueta_id_foreign` (`etiqueta_id`),
  ADD KEY `planificacion_item_planificacion_id_foreign` (`planificacion_id`);

--
-- Indices de la tabla `recetas`
--
ALTER TABLE `recetas`
  ADD PRIMARY KEY (`receta_id`),
  ADD KEY `recetas_usuario_id_foreign` (`usuario_id`),
  ADD KEY `recetas_tipo_id_foreign` (`tipo_id`);

--
-- Indices de la tabla `recetasitems`
--
ALTER TABLE `recetasitems`
  ADD PRIMARY KEY (`recetaItem_id`),
  ADD KEY `recetasitems_ingrediente_id_foreign` (`ingrediente_id`),
  ADD KEY `recetasitems_usuario_id_foreign` (`usuario_id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`tipo_id`);

--
-- Indices de la tabla `unidades`
--
ALTER TABLE `unidades`
  ADD PRIMARY KEY (`unidad_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usuario_id`),
  ADD UNIQUE KEY `usuarios_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `categoria_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `cliente_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `clienteservicios`
--
ALTER TABLE `clienteservicios`
  MODIFY `clienteServicio_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `condiciones`
--
ALTER TABLE `condiciones`
  MODIFY `condicion_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `etiquetas`
--
ALTER TABLE `etiquetas`
  MODIFY `etiqueta_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ingredientes`
--
ALTER TABLE `ingredientes`
  MODIFY `ingrediente_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `planificacion`
--
ALTER TABLE `planificacion`
  MODIFY `planificacion_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `planificacion_item`
--
ALTER TABLE `planificacion_item`
  MODIFY `planificacionItem_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `recetas`
--
ALTER TABLE `recetas`
  MODIFY `receta_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `recetasitems`
--
ALTER TABLE `recetasitems`
  MODIFY `recetaItem_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `tipo_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `unidades`
--
ALTER TABLE `unidades`
  MODIFY `unidad_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `usuario_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_condicion_id_foreign` FOREIGN KEY (`condicion_id`) REFERENCES `condiciones` (`condicion_id`),
  ADD CONSTRAINT `clientes_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `clienteservicios`
--
ALTER TABLE `clienteservicios`
  ADD CONSTRAINT `clienteservicios_etiqueta_id_foreign` FOREIGN KEY (`etiqueta_id`) REFERENCES `etiquetas` (`etiqueta_id`),
  ADD CONSTRAINT `clienteservicios_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `ingredientes`
--
ALTER TABLE `ingredientes`
  ADD CONSTRAINT `ingredientes_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`categoria_id`),
  ADD CONSTRAINT `ingredientes_unidad_id_foreign` FOREIGN KEY (`unidad_id`) REFERENCES `unidades` (`unidad_id`),
  ADD CONSTRAINT `ingredientes_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `planificacion`
--
ALTER TABLE `planificacion`
  ADD CONSTRAINT `planificacion_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`),
  ADD CONSTRAINT `planificacion_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `planificacion_item`
--
ALTER TABLE `planificacion_item`
  ADD CONSTRAINT `planificacion_item_etiqueta_id_foreign` FOREIGN KEY (`etiqueta_id`) REFERENCES `etiquetas` (`etiqueta_id`),
  ADD CONSTRAINT `planificacion_item_planificacion_id_foreign` FOREIGN KEY (`planificacion_id`) REFERENCES `planificacion` (`planificacion_id`),
  ADD CONSTRAINT `planificacion_item_receta_id_foreign` FOREIGN KEY (`receta_id`) REFERENCES `recetas` (`receta_id`),
  ADD CONSTRAINT `planificacion_item_tipo_id_foreign` FOREIGN KEY (`tipo_id`) REFERENCES `tipos` (`tipo_id`),
  ADD CONSTRAINT `planificacion_item_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `recetas`
--
ALTER TABLE `recetas`
  ADD CONSTRAINT `recetas_tipo_id_foreign` FOREIGN KEY (`tipo_id`) REFERENCES `tipos` (`tipo_id`),
  ADD CONSTRAINT `recetas_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);

--
-- Filtros para la tabla `recetasitems`
--
ALTER TABLE `recetasitems`
  ADD CONSTRAINT `recetasitems_ingrediente_id_foreign` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredientes` (`ingrediente_id`),
  ADD CONSTRAINT `recetasitems_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`usuario_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
